module.exports = {
    service: 'ws://114.55.253.187:3001/'
};